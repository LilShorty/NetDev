﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmGrades
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtInput1 = New System.Windows.Forms.TextBox()
        Me.txtOutput1 = New System.Windows.Forms.TextBox()
        Me.txtInput2 = New System.Windows.Forms.TextBox()
        Me.txtOutput2 = New System.Windows.Forms.TextBox()
        Me.txtInput3 = New System.Windows.Forms.TextBox()
        Me.txtOutput3 = New System.Windows.Forms.TextBox()
        Me.txtOutput4 = New System.Windows.Forms.TextBox()
        Me.txtInput4 = New System.Windows.Forms.TextBox()
        Me.txtInput5 = New System.Windows.Forms.TextBox()
        Me.txtOutput5 = New System.Windows.Forms.TextBox()
        Me.txtOutput6 = New System.Windows.Forms.TextBox()
        Me.txtOutput7 = New System.Windows.Forms.TextBox()
        Me.txtSemesterAvg1 = New System.Windows.Forms.TextBox()
        Me.txtInput7 = New System.Windows.Forms.TextBox()
        Me.txtInput6 = New System.Windows.Forms.TextBox()
        Me.txtSemesterAvg2 = New System.Windows.Forms.TextBox()
        Me.txtResult = New System.Windows.Forms.TextBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(69, 17)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Course 1:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 37)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(69, 17)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "Course 2:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 65)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(69, 17)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Course 3:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 93)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(69, 17)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "Course 4:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 121)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(69, 17)
        Me.Label5.TabIndex = 14
        Me.Label5.Text = "Course 5:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(12, 149)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(69, 17)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "Course 6:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(12, 177)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(69, 17)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "Course 7:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(12, 205)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(76, 17)
        Me.Label8.TabIndex = 17
        Me.Label8.Text = "Semester :"
        '
        'txtInput1
        '
        Me.txtInput1.Location = New System.Drawing.Point(153, 6)
        Me.txtInput1.Name = "txtInput1"
        Me.txtInput1.Size = New System.Drawing.Size(100, 22)
        Me.txtInput1.TabIndex = 0
        '
        'txtOutput1
        '
        Me.txtOutput1.Location = New System.Drawing.Point(259, 6)
        Me.txtOutput1.Name = "txtOutput1"
        Me.txtOutput1.ReadOnly = True
        Me.txtOutput1.Size = New System.Drawing.Size(100, 22)
        Me.txtOutput1.TabIndex = 19
        '
        'txtInput2
        '
        Me.txtInput2.Location = New System.Drawing.Point(153, 34)
        Me.txtInput2.Name = "txtInput2"
        Me.txtInput2.Size = New System.Drawing.Size(100, 22)
        Me.txtInput2.TabIndex = 1
        '
        'txtOutput2
        '
        Me.txtOutput2.Location = New System.Drawing.Point(259, 34)
        Me.txtOutput2.Name = "txtOutput2"
        Me.txtOutput2.ReadOnly = True
        Me.txtOutput2.Size = New System.Drawing.Size(100, 22)
        Me.txtOutput2.TabIndex = 20
        '
        'txtInput3
        '
        Me.txtInput3.Location = New System.Drawing.Point(153, 62)
        Me.txtInput3.Name = "txtInput3"
        Me.txtInput3.Size = New System.Drawing.Size(100, 22)
        Me.txtInput3.TabIndex = 2
        '
        'txtOutput3
        '
        Me.txtOutput3.Location = New System.Drawing.Point(259, 62)
        Me.txtOutput3.Name = "txtOutput3"
        Me.txtOutput3.ReadOnly = True
        Me.txtOutput3.Size = New System.Drawing.Size(100, 22)
        Me.txtOutput3.TabIndex = 21
        '
        'txtOutput4
        '
        Me.txtOutput4.Location = New System.Drawing.Point(259, 90)
        Me.txtOutput4.Name = "txtOutput4"
        Me.txtOutput4.ReadOnly = True
        Me.txtOutput4.Size = New System.Drawing.Size(100, 22)
        Me.txtOutput4.TabIndex = 22
        '
        'txtInput4
        '
        Me.txtInput4.Location = New System.Drawing.Point(153, 90)
        Me.txtInput4.Name = "txtInput4"
        Me.txtInput4.Size = New System.Drawing.Size(100, 22)
        Me.txtInput4.TabIndex = 3
        '
        'txtInput5
        '
        Me.txtInput5.Location = New System.Drawing.Point(153, 118)
        Me.txtInput5.Name = "txtInput5"
        Me.txtInput5.Size = New System.Drawing.Size(100, 22)
        Me.txtInput5.TabIndex = 4
        '
        'txtOutput5
        '
        Me.txtOutput5.Location = New System.Drawing.Point(259, 118)
        Me.txtOutput5.Name = "txtOutput5"
        Me.txtOutput5.ReadOnly = True
        Me.txtOutput5.Size = New System.Drawing.Size(100, 22)
        Me.txtOutput5.TabIndex = 23
        '
        'txtOutput6
        '
        Me.txtOutput6.Location = New System.Drawing.Point(259, 146)
        Me.txtOutput6.Name = "txtOutput6"
        Me.txtOutput6.ReadOnly = True
        Me.txtOutput6.Size = New System.Drawing.Size(100, 22)
        Me.txtOutput6.TabIndex = 24
        '
        'txtOutput7
        '
        Me.txtOutput7.Location = New System.Drawing.Point(259, 174)
        Me.txtOutput7.Name = "txtOutput7"
        Me.txtOutput7.ReadOnly = True
        Me.txtOutput7.Size = New System.Drawing.Size(100, 22)
        Me.txtOutput7.TabIndex = 25
        '
        'txtSemesterAvg1
        '
        Me.txtSemesterAvg1.Location = New System.Drawing.Point(153, 202)
        Me.txtSemesterAvg1.Name = "txtSemesterAvg1"
        Me.txtSemesterAvg1.ReadOnly = True
        Me.txtSemesterAvg1.Size = New System.Drawing.Size(100, 22)
        Me.txtSemesterAvg1.TabIndex = 18
        '
        'txtInput7
        '
        Me.txtInput7.Location = New System.Drawing.Point(153, 174)
        Me.txtInput7.Name = "txtInput7"
        Me.txtInput7.Size = New System.Drawing.Size(100, 22)
        Me.txtInput7.TabIndex = 6
        '
        'txtInput6
        '
        Me.txtInput6.Location = New System.Drawing.Point(153, 146)
        Me.txtInput6.Name = "txtInput6"
        Me.txtInput6.Size = New System.Drawing.Size(100, 22)
        Me.txtInput6.TabIndex = 5
        '
        'txtSemesterAvg2
        '
        Me.txtSemesterAvg2.Location = New System.Drawing.Point(259, 202)
        Me.txtSemesterAvg2.Name = "txtSemesterAvg2"
        Me.txtSemesterAvg2.ReadOnly = True
        Me.txtSemesterAvg2.Size = New System.Drawing.Size(100, 22)
        Me.txtSemesterAvg2.TabIndex = 26
        '
        'txtResult
        '
        Me.txtResult.Location = New System.Drawing.Point(15, 225)
        Me.txtResult.Multiline = True
        Me.txtResult.Name = "txtResult"
        Me.txtResult.ReadOnly = True
        Me.txtResult.Size = New System.Drawing.Size(344, 195)
        Me.txtResult.TabIndex = 27
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(15, 426)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(86, 23)
        Me.btnCalculate.TabIndex = 7
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(178, 426)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 23)
        Me.btnReset.TabIndex = 8
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(284, 426)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 9
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmGrades
        '
        Me.AcceptButton = Me.btnCalculate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnExit
        Me.ClientSize = New System.Drawing.Size(369, 457)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtResult)
        Me.Controls.Add(Me.txtSemesterAvg2)
        Me.Controls.Add(Me.txtInput6)
        Me.Controls.Add(Me.txtInput7)
        Me.Controls.Add(Me.txtSemesterAvg1)
        Me.Controls.Add(Me.txtOutput7)
        Me.Controls.Add(Me.txtOutput6)
        Me.Controls.Add(Me.txtOutput5)
        Me.Controls.Add(Me.txtInput5)
        Me.Controls.Add(Me.txtInput4)
        Me.Controls.Add(Me.txtOutput4)
        Me.Controls.Add(Me.txtOutput3)
        Me.Controls.Add(Me.txtInput3)
        Me.Controls.Add(Me.txtOutput2)
        Me.Controls.Add(Me.txtInput2)
        Me.Controls.Add(Me.txtOutput1)
        Me.Controls.Add(Me.txtInput1)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmGrades"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents txtInput1 As TextBox
    Friend WithEvents txtOutput1 As TextBox
    Friend WithEvents txtInput2 As TextBox
    Friend WithEvents txtOutput2 As TextBox
    Friend WithEvents txtInput3 As TextBox
    Friend WithEvents txtOutput3 As TextBox
    Friend WithEvents txtOutput4 As TextBox
    Friend WithEvents txtInput4 As TextBox
    Friend WithEvents txtInput5 As TextBox
    Friend WithEvents txtOutput5 As TextBox
    Friend WithEvents txtOutput6 As TextBox
    Friend WithEvents txtOutput7 As TextBox
    Friend WithEvents txtSemesterAvg1 As TextBox
    Friend WithEvents txtInput7 As TextBox
    Friend WithEvents txtInput6 As TextBox
    Friend WithEvents txtSemesterAvg2 As TextBox
    Friend WithEvents txtResult As TextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
End Class
