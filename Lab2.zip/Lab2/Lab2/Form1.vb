﻿' Author: Joshua Anderson
' Last Modified: Febuary 9th 2020
' Original Author: Joshua Anderson
' Start Date: Febuary 9, 2020
' Description:tells you your letter grade based off of a number grade between 0 and 100


Public Class frmGrades

    'Variable declaration
    Dim textBoxList As TextBox()
    Dim textBoxList2 As TextBox()
    Dim semesterAverage As Double

    Private Sub frmGrades_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        textBoxList = {txtInput1, txtInput2, txtInput3, txtInput4, txtInput5, txtInput6, txtInput7}
        textBoxList2 = {txtInput1, txtInput2, txtInput3, txtInput4, txtInput5, txtInput6, txtInput7, txtOutput1, txtOutput2, txtOutput3, txtOutput4, txtOutput5, txtOutput6, txtOutput7, txtSemesterAvg2, txtSemesterAvg1}
    End Sub

    Private Sub txtInput1_LostFocus(sender As Object, e As EventArgs) Handles txtInput1.LostFocus
        If ValidateTextbox(txtInput1) Then
            txtResult.Text = String.Empty
            grade(txtInput1.Text, txtOutput:=txtOutput1)
            Disable(txtInput1)
        End If

    End Sub

    Private Sub txtInput2_LostFocus(sender As Object, e As EventArgs) Handles txtInput2.LostFocus
        If ValidateTextbox(txtInput2) Then
            txtResult.Text = String.Empty
            grade(txtInput2.Text, txtOutput:=txtOutput2)
            Disable(txtInput2)
        End If
    End Sub

    Private Sub txtInput3_LostFocus(sender As Object, e As EventArgs) Handles txtInput3.LostFocus
        If ValidateTextbox(txtInput3) Then
            txtResult.Text = String.Empty
            grade(txtInput3.Text, txtOutput:=txtOutput3)
            Disable(txtInput3)
        End If
    End Sub
    Private Sub txtInput4_LostFocus(sender As Object, e As EventArgs) Handles txtInput4.LostFocus
        If ValidateTextbox(txtInput4) Then
            txtResult.Text = String.Empty
            grade(txtInput4.Text, txtOutput:=txtOutput4)
            Disable(txtInput4)
        End If
    End Sub
    Private Sub txtInput5_LostFocus(sender As Object, e As EventArgs) Handles txtInput5.LostFocus
        If ValidateTextbox(txtInput5) Then
            txtResult.Text = String.Empty
            grade(txtInput5.Text, txtOutput:=txtOutput5)
            Disable(txtInput5)
        End If
    End Sub
    Private Sub txtInput6_LostFocus(sender As Object, e As EventArgs) Handles txtInput6.LostFocus
        If ValidateTextbox(txtInput6) Then
            txtResult.Text = String.Empty
            grade(txtInput6.Text, txtOutput:=txtOutput6)
            Disable(txtInput6)
        End If
    End Sub
    Private Sub txtInput7_LostFocus(sender As Object, e As EventArgs) Handles txtInput7.LostFocus
        If ValidateTextbox(txtInput7) Then
            txtResult.Text = String.Empty
            grade(txtInput7.Text, txtOutput:=txtOutput7)
            Disable(txtInput7)
        End If
    End Sub
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        semesterAverage = Math.Round(semesterAverage / textBoxList.Length, 2)
        txtSemesterAvg1.Text = semesterAverage
        grade(txtSemesterAvg1.Text, txtSemesterAvg2)
        btnCalculate.Enabled = False
    End Sub
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        SetDefaults()
        btnCalculate.Enabled = True
        SetTextboxesEnabled(textBoxList, True)
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub


#Region "Procedures"

    Function ValidateTextbox(txtInput As TextBox) As Boolean

        ' Variable declaration
        Dim inputGrade As Double

        'Tryparse to check for a numeric value
        If Double.TryParse(txtInput.Text, inputGrade) Then

            'if statements to check  proper number
            If inputGrade < 0 Then
                txtInput.Select()
                txtResult.Text = "Input is too low"
                Return False
            ElseIf inputGrade > 100 Then
                txtInput.Select()
                txtResult.Text = "Input is too High"
                Return False
            Else
                txtResult.Text = ""
                Return True
            End If
        Else
            txtInput.Select()
            txtResult.Text = "Input must be numeric"
            Return False

        End If

    End Function

    Sub grade(ByVal txtInput As Double, ByRef txtOutput As TextBox)

        txtInput = Math.Round(txtInput, 0)
        semesterAverage += txtInput
        If txtInput < 50 Then
            txtOutput.Text = "F"
        ElseIf txtInput >= 50 And txtInput <= 54 Then
            txtOutput.Text = "D"
        ElseIf txtInput >= 55 And txtInput <= 59 Then
            txtOutput.Text = "D+"
        ElseIf txtInput >= 60 And txtInput <= 64 Then
            txtOutput.Text = "C"
        ElseIf txtInput >= 65 And txtInput <= 69 Then
            txtOutput.Text = "B-"
        ElseIf txtInput >= 70 And txtInput <= 74 Then
            txtOutput.Text = "B"
        ElseIf txtInput >= 75 And txtInput <= 79 Then
            txtOutput.Text = "B+"
        ElseIf txtInput >= 80 And txtInput <= 84 Then
            txtOutput.Text = "A-"
        ElseIf txtInput >= 85 And txtInput <= 89 Then
            txtOutput.Text = "A"
        Else
            txtOutput.Text = "A+"
        End If

    End Sub


    Sub SetDefaults()
        ClearControls(textBoxList2)
    End Sub

    Sub ClearControls(controlArray As Control())


        For Each controlToClear As Control In controlArray
            controlToClear.Text = String.Empty
        Next

    End Sub

    Sub Disable(ByRef txtInput As TextBox)
        txtInput.Enabled = False
    End Sub

    Sub SetTextboxesEnabled(textboxArray As TextBox(), enabledStatus As Boolean)


        For Each textboxToSet As TextBox In textboxArray
            textboxToSet.Enabled = enabledStatus
        Next

    End Sub


#End Region
End Class
